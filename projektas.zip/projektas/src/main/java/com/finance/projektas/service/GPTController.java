package com.finance.projektas.service;

import com.finance.projektas.service.GPTService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * This controller handles requests to get advice from chatgpt
 * It uses the gptservice to get a response
 */

@RestController
@RequestMapping("/api/gpt")
public class GPTController {

    private final GPTService gptService;

    /**
     * Constructor to set gpt service
     * @param gptService the service that calls chatgpt
     */

    public GPTController(GPTService gptService) {
        this.gptService = gptService;
    }

    /**
     * Gets advice
     * @return a message with advice or an error message
     */

    @GetMapping("/advice")
    public ResponseEntity<String> getAdvice() {
        try {
            String result = gptService.getAdviceFromChatGPT();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error: " + e.getMessage());
        }
    }
}
