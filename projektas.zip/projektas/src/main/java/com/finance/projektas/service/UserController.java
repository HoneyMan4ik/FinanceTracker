package com.finance.projektas.service;

import com.finance.projektas.model.User;
import com.finance.projektas.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * This controller handles user registration and login
 * It works with the UserService class
 */

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    /**
     * Constructor to set the user service
     * @param userService the service used for user actions
     */

    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Register a new user
     * @param user the user object with username and password
     * @return the saved user
     */

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.register(user);
    }

    /**
     * Login a user by checking username and password
     * @param user the user object with username and password
     * @return success message or unauthorized error
     */

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User user) {
        boolean success = userService.login(user.getUsername(), user.getPassword());
        if (success) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
    }
}
