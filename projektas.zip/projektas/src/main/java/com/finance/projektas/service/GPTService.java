package com.finance.projektas.service;

import com.finance.projektas.model.FinanceRecord;
import com.finance.projektas.repository.FinanceRecordRepository;
import org.springframework.stereotype.Service;

import java.net.http.*;
import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This service is used to get financial advice from chatgpt
 * It collects user's finance records and sends them as a prompt to the openai API
 */

@Service
public class GPTService {

    private final FinanceRecordRepository recordRepository;

    /**
     * Constructor to set the finance record repository
     * @param recordRepository the repository used to get all finance records
     */

    public GPTService(FinanceRecordRepository recordRepository) {
        this.recordRepository = recordRepository;
    }

    /**
     * Sends finance record summary to chatgpt and gets advice
     * @return advice message from chatpgt
     * @throws Exception if the API call fails
     */

    public String getAdviceFromChatGPT() throws Exception {
        List<FinanceRecord> records = recordRepository.findAll();

        String expenseSummary = records.stream()
                .map(r -> r.getCategory() + " – " + r.getAmount() + "€")
                .collect(Collectors.joining(", "));

        String prompt = "Here are my expense records: " + expenseSummary +
                ". Summarize the main spending categories and provide advice on how to reduce expenses.";

        String requestBody = """
            {
              "model": "gpt-3.5-turbo",
              "messages": [{"role": "user", "content": "%s"}],
              "temperature": 0.7
            }
        """.formatted(prompt);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + "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")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        return response.body();
    }
}
