package com.finance.projektas.service;

import com.finance.projektas.model.FinanceRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * This class handles all HTTP requests for finance records
 * You can add, update, delete, and view finance records using this controller
 */

@RestController
@RequestMapping("/api/finance")
public class FinanceRecordController {

    @Autowired
    private FinanceRecordService financeRecordService;

    /**
     * Get all finance records from the db
     * @return A list of all finance records
     */

    @GetMapping
    public ResponseEntity<List<FinanceRecord>> getAllRecords() {
        List<FinanceRecord> records = financeRecordService.getAllRecords();
        return ResponseEntity.ok()
                .header(HttpHeaders.CACHE_CONTROL, "max-age=3600")
                .body(records);
    }

    /**
     * Get one finance record by its id
     * @param id The ID of the finance record
     * @return The finance record or 404 if not found
     */

    @GetMapping("/{id}")
    public ResponseEntity<FinanceRecord> getRecordById(@PathVariable Long id) {
        return financeRecordService.getRecordById(id)
                .map(record -> ResponseEntity.ok()
                        .header(HttpHeaders.CACHE_CONTROL, "max-age=3600")
                        .body(record))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Create a new finance record and save it to the db
     * @param record The finance record to create
     * @return A success message
     */

    @PostMapping
    public ResponseEntity<String> createRecord(@RequestBody FinanceRecord record) {
        financeRecordService.saveRecord(record);
        return ResponseEntity.ok("Record created successfully");
    }

    /**
     * Updates an existing finance record
     * @param id The ID of the record to update
     * @param updatedRecord The new record data
     * @return A success message or 404 if not found
     */

    @PutMapping("/{id}")
    public ResponseEntity<String> updateRecord(@PathVariable Long id, @RequestBody FinanceRecord updatedRecord) {
        Optional<FinanceRecord> recordOpt = financeRecordService.getRecordById(id);

        if (recordOpt.isPresent()) {
            FinanceRecord record = recordOpt.get();
            record.setTitle(updatedRecord.getTitle());
            record.setAmount(updatedRecord.getAmount());
            record.setDate(updatedRecord.getDate());
            record.setCategory(updatedRecord.getCategory());

            financeRecordService.saveRecord(record);

            return ResponseEntity.ok("Record updated successfully");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    /**
     * Updates some field(s) of a finance record (not all)
     * @param id The ID of the record
     * @param updates The fields and values to change
     * @return A success message or 404 if not found
     */

    @PatchMapping("/{id}")
    public ResponseEntity<String> partiallyUpdateRecord(@PathVariable Long id, @RequestBody Map<String, Object> updates) {
        Optional<FinanceRecord> recordOpt = financeRecordService.getRecordById(id);

        if (recordOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        FinanceRecord record = recordOpt.get();

        updates.forEach((String key, Object value) -> {
            switch (key) {
                case "title" -> record.setTitle((String) value);
                case "amount" -> record.setAmount(Double.parseDouble(value.toString()));
                case "date" -> record.setDate(LocalDate.parse((String) value));
                case "category" -> record.setCategory((String) value);
            }
        });

        financeRecordService.saveRecord(record);
        return ResponseEntity.ok("Record updated partially");
    }

    /**
     * Delete a finance record by its id
     * @param id The id of the record
     * @return A success message or 404 if not found
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRecord(@PathVariable Long id) {
        boolean deleted = financeRecordService.deleteRecordById(id);
        if (deleted) {
            return ResponseEntity.ok("Record deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get a summary of all finance records for one user
     * @param username The user's names
     * @return A map of summary information
     */

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getSummary(@RequestParam String username) {
        Map<String, Object> summary = financeRecordService.getSummaryByUsername(username);
        return ResponseEntity.ok(summary);
    }
}