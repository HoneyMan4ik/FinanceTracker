package com.finance.projektas.service;

import com.finance.projektas.model.User;
import com.finance.projektas.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    /**
     * This service handles action related to users
     * It works with the UserRepository to save and find users
     */

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Register a new user (save to db)
     * @param user the user to register
     * @return the saved user
     */

    public User register(User user) {
        return userRepository.save(user);
    }

    /**
     * Check if the username and password are correct
     * @param username the user's name
     * @param password the user's password
     * @return true if login is successful, false otherwise
     */

    public boolean login(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        return userOpt.isPresent() && userOpt.get().getPassword().equals(password);
    }

    /**
     * Find a user by username
     * @param username the name to search
     * @return Optional with the user if found
     */

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
