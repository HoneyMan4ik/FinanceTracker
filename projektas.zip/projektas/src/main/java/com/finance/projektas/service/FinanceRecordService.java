package com.finance.projektas.service;

import com.finance.projektas.model.FinanceRecord;
import com.finance.projektas.model.User;
import com.finance.projektas.repository.FinanceRecordRepository;
import com.finance.projektas.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * This class handles business logic for finance records
 * It talks to the db using FinanceRecordRepository and UserRepository
 */

@Service
public class FinanceRecordService {

    private final FinanceRecordRepository recordRepository;
    private final UserRepository userRepository;

    /**
     * Constructor to set up repositories
     * @param recordRepository Repository for finance records
     * @param userRepository Repository for users
     */

    public FinanceRecordService(FinanceRecordRepository recordRepository,UserRepository userRepository) {
        this.recordRepository = recordRepository;
        this.userRepository = userRepository;
    }

    /**
     * Get all finance records from the db
     * @return List of all finance records
     */

    public List<FinanceRecord> getAllRecords() {
        return recordRepository.findAll();
    }

    /**
     * Get one finance record by id
     * @param id The id of the record
     * @return Optional with the record (or empty if not found)
     */

    public Optional<FinanceRecord> getRecordById(Long id) {
        return recordRepository.findById(id);
    }

    /**
     * Save a finance record to the db
     * Can be used to add or update
     * @param record The record to save
     */

    public void saveRecord(FinanceRecord record) {
        recordRepository.save(record);
    }

    /**
     * Delete a record by id
     * @param id The id of the record
     * @return true if deleted, false if not found
     */

    public boolean deleteRecordById(Long id) {
        if (recordRepository.existsById(id)) {
            recordRepository.deleteById(id);
            return true;
        }
        return false;
    }

    /**
     * Get a summary (total income and expenses) for a user
     * @param username The user's name
     * @return A map with totalIncome and totalExpenses
     */

    public Map<String, Object> getSummaryByUsername(String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isEmpty()) return Map.of("error", "User not found");

        List<FinanceRecord> records = recordRepository.findAll().stream()
                .filter(r -> r.getUser() != null && r.getUser().getUsername().equals(username))
                .collect(Collectors.toList());

        double total = Math.round(
                records.stream().mapToDouble(FinanceRecord::getAmount).sum() * 100.0
        ) / 100.0;
        Map<String, Double> byCategory = records.stream()
                .collect(Collectors.groupingBy(FinanceRecord::getCategory,
                        Collectors.summingDouble(FinanceRecord::getAmount)));

        Map<String, Object> summary = new HashMap<>();
        summary.put("totalAmount", total);
        summary.put("byCategory", byCategory);
        summary.put("recordCount", records.size());
        return summary;
    }
}