package com.finance.projektas.repository;

import com.finance.projektas.model.FinanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import com.finance.projektas.model.User;

import java.util.List;


public interface FinanceRecordRepository extends JpaRepository<FinanceRecord, Long> {
    List<FinanceRecord> findByUser(User user);
}
