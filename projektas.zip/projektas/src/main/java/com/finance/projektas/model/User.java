package com.finance.projektas.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

/**
 * This class represents a user
 * Each user has a username, password and a list of finance records
 */

@Entity
@Table(name = "app_user")
@Data
public class User {

    /** The unique id of the user (auto generated) */

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Username */

    @Column(unique = true)
    private String username;

    /** The user's password */

    private String password;

    /**
     * List of finance records that belong to this user
     * One user can have many finance records
     */

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<FinanceRecord> financeRecords;

}
